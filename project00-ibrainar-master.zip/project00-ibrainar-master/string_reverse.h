#ifndef STRING_REVERSE_H
#define STRING_REVERSE_H

char *string_reverse(char *s);

#endif
