#ifndef STRING_BLANKS_H
#define STRING_BLANKS_H

char **string_blanks(char *s);

#endif
